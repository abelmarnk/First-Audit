import * as anchor from "@coral-xyz/anchor";
import { Program } from "@coral-xyz/anchor";
import { WagerProgram } from "../app/src/app/types/wager_program";
import * as types from "./types";
import { BN } from "@coral-xyz/anchor";
import { assert } from "chai";
import {
  getSessionId,
  getGameSessionKey,
  getVaultKey,
  airdropToAccount,
  airdropToAccounts,
  getTokenBalance,
  getGlobalConfigKey,
  getMintKey,
  getGameServerKeypair,
  getVaultTokenAccount,
  SPAWNS_PER_DEPOSIT,
  extractPlayerStats,
  calculateExpectedEarnings,
  generateRandomKillTuple,
  getSortedAndCreatorIndex,
  setupTokenAccount,
  BASE_TOKEN_AMOUNT
} from "./utils";
import { 
  ConfirmOptions, 
  Keypair, 
  PublicKey,
} from "@solana/web3.js";

const confirmOptions: ConfirmOptions = { commitment: "confirmed" };

describe("Distribute Winnings", () => {
  // Set up environment
  const provider = anchor.AnchorProvider.env();
  anchor.setProvider(provider);
  const program = anchor.workspace.WagerProgram as Program<WagerProgram>;

  const mintKey = getMintKey();
  let gameServerKeypair:Keypair;

  const wagerAmount = new BN(BASE_TOKEN_AMOUNT/10); // 0.1 tokens

  const user1 = Keypair.generate();
  const user2 = Keypair.generate();
  const user3 = Keypair.generate();
  const user4 = Keypair.generate();
  const user5 = Keypair.generate();
  const user6 = Keypair.generate();
  const user7 = Keypair.generate();
  const user8 = Keypair.generate();
  const user9 = Keypair.generate();
  const user10 = Keypair.generate();

  let user1TokenAccount: PublicKey;
  let user2TokenAccount: PublicKey;
  let user3TokenAccount: PublicKey;
  let user4TokenAccount: PublicKey;
  let user5TokenAccount: PublicKey;
  let user6TokenAccount: PublicKey;
  let user7TokenAccount: PublicKey;
  let user8TokenAccount: PublicKey;
  let user9TokenAccount: PublicKey;
  let user10TokenAccount: PublicKey;


  let globalConfigKey = getGlobalConfigKey(
      program.programId
    );

  before(async () => {   
    
    gameServerKeypair = getGameServerKeypair();

    // Setup accounts
    await airdropToAccount(provider.connection, gameServerKeypair.publicKey);

    await airdropToAccounts(provider.connection, [
      user1.publicKey, user2.publicKey, user3.publicKey, 
      user4.publicKey, user5.publicKey, user6.publicKey
    ]);

    // Create token accounts and mint tokens
    const keypairs = [user1, user2, user3, user4, user5, user6];
    const tokenAccounts: PublicKey[] = [];

    for (let i = 0; i < keypairs.length; i++) {
      tokenAccounts[i] = await setupTokenAccount(
        provider.connection,
        gameServerKeypair,       
        mintKey,
        keypairs[i].publicKey
      );
    }

    // assign back
    [
      user1TokenAccount,
      user2TokenAccount,
      user3TokenAccount,
      user4TokenAccount,
      user5TokenAccount,
      user6TokenAccount
    ] = tokenAccounts;

    console.log("Accounts completely setup!!!");

  });

  it("Successfully distributes winnings to winning team in 1v1 winner-takes-all", async () => {
    const sessionId = getSessionId(31);

    const gameSessionKey = getGameSessionKey(program.programId, sessionId);

    const vaultKey = getVaultKey(program.programId, sessionId);

    const vaultTokenAccountKey = getVaultTokenAccount(mintKey, vaultKey);

    console.log("Initial balances:-\n\n");
    const user1InitialBalance = await getTokenBalance(provider.connection, user1TokenAccount);
    const user2InitialBalance = await getTokenBalance(provider.connection, user2TokenAccount);
    console.log("User 1:-", user1InitialBalance);
    console.log("User 2:-", user2InitialBalance);

    // Arguments for the `create_game_session` instruction
    const createGameSessionArgs: types.CreateGameSessionArgs = {
      sessionId: sessionId,
      wagerAmount: wagerAmount,
      gameMode: {winnerTakesAllOneVsOne: {}},
      creatorTeam: 0, // Team A
      creatorIndex:0,      
      teamA: [user1.publicKey],
      teamB: []
    };

    // Create the game session and join user1
    await program.methods
      .createGameSession(createGameSessionArgs)
      .accountsPartial({
        user: user1.publicKey,
        gameSession: gameSessionKey,
        userTokenAccount: user1TokenAccount,
        mint: mintKey,
      })
      .signers([user1])
      .rpc(confirmOptions);

    // Arguments for the `join_user` instruction
    const joinArgs: types.JoinUserArgs = {
      team: 1 // Team B
    };

    // Join user2
    await program.methods
      .joinUser(joinArgs)
      .accountsPartial({
        user: user2.publicKey,
        gameSession: gameSessionKey,
        userTokenAccount: user2TokenAccount,
        mint: mintKey,
      })
      .signers([user2])
      .rpc(confirmOptions);

    console.log("After creation & joins - Vault balance:- ", 
      await getTokenBalance(provider.connection, vaultTokenAccountKey));

    // Arguments for the `distribute_winnings` instruction
    const distributeArgs: types.DistributeWinningsArgs = {
      winningTeam: 0 // Team A wins
    };

    // Kills are ignored for the purpose of simulation, since the server controls the kills
    // It can be assumed that they are enforced as they should.

    // Distibute the winnings
    await program.methods
      .distributeWinnings(distributeArgs)
      .accountsPartial({
        globalConfig: globalConfigKey,
        server: gameServerKeypair.publicKey,
        creator: user1.publicKey,
        creatorTokenAccount: user1TokenAccount,
        gameSession: gameSessionKey,
      })
      .remainingAccounts([
        {
          pubkey: user1.publicKey,
          isSigner: false,
          isWritable: true,
        },
        {
          pubkey: user1TokenAccount,
          isSigner: false,
          isWritable: true,
        }
      ])
      .signers([gameServerKeypair])
      .rpc(confirmOptions);

    console.log("Final balances:- \n\n");

    const user1FinalBalance = await getTokenBalance(provider.connection, user1TokenAccount);

    const user2FinalBalance = await getTokenBalance(provider.connection, user2TokenAccount);

    console.log("User 1:-", user1FinalBalance);

    console.log("User 2:-", user2FinalBalance);

    const difference = wagerAmount.toNumber();

    // User1 should have won the other wager and got 0.1 tokens

    console.log("User 1 difference: ", user1FinalBalance - user1InitialBalance)
    console.log("User 2 difference: ", user2FinalBalance - user2InitialBalance)

    assert.equal(user1FinalBalance - user1InitialBalance, difference); // + 0.1 tokens
    assert.equal(user2FinalBalance - user2InitialBalance, -difference);  // - 0.1 tokens

  });

  it("Successfully distributes winnings to winning team in 3v3 winner-takes-all", async () => {
    const sessionId = getSessionId(32);

    const gameSessionKey = getGameSessionKey(program.programId, sessionId);

    const vaultKey = getVaultKey(program.programId, sessionId);

    const vaultTokenAccountKey = getVaultTokenAccount(mintKey, vaultKey);

    let initialBalances: number[] = []

    console.log("Initial balances:- \n\n");
    for (let i = 1; i <= 6; i++) {
      const tokenAccount = eval(`user${i}TokenAccount`) as PublicKey;
      initialBalances.push(await getTokenBalance(provider.connection, tokenAccount));
      console.log(`User ${i}:`, initialBalances[i - 1]);
    }

    // Sort to reduce lamports(gas) spent
    const [index, teamA] = getSortedAndCreatorIndex([user1.publicKey, user3.publicKey]);
    const teamB = getSortedAndCreatorIndex([user2.publicKey, user4.publicKey])[1];

    // Arguments for the `create_game_session` instruction
    const createGameSessionArgs: types.CreateGameSessionArgs = {
      sessionId: sessionId,
      wagerAmount: wagerAmount,
      gameMode: { winnerTakesAllThreeVsThree: {} },
      creatorTeam: 0, // Team A
      creatorIndex: index,
      teamA,
      teamB
    };

    // Create the game session, reserve space for some users and join user1
    await program.methods
      .createGameSession(createGameSessionArgs)
      .accountsPartial({
        user: user1.publicKey,
        gameSession: gameSessionKey,
        vault: vaultKey,
        userTokenAccount: user1TokenAccount,
        mint: mintKey,
      })
      .signers([user1])
      .rpc(confirmOptions);

    // Join remaining players
    const joinConfigs = [
      { user: user2, tokenAccount: user2TokenAccount, team: 1 }, // Team B
      { user: user3, tokenAccount: user3TokenAccount, team: 0 }, // Team A
      { user: user4, tokenAccount: user4TokenAccount, team: 1 }, // Team B
      { user: user5, tokenAccount: user5TokenAccount, team: 0 }, // Team A
      { user: user6, tokenAccount: user6TokenAccount, team: 1 }  // Team B
    ];

    for (const config of joinConfigs) {
      // Argument for the `join_user` instruction
      const joinArgs: types.JoinUserArgs = {
        team: config.team
      };

      // join user
      await program.methods
        .joinUser(joinArgs)
        .accountsPartial({
          user: config.user.publicKey,
          gameSession: gameSessionKey,
          userTokenAccount: config.tokenAccount,
          mint: mintKey,
        })
        .signers([config.user])
        .rpc(confirmOptions);
    }

    console.log("After all joins - Vault balance:- ", 
      await getTokenBalance(provider.connection, vaultTokenAccountKey));

      // Argument for the `distribute_winnings` instruction
      const distributeArgs: types.DistributeWinningsArgs = {
      winningTeam: 0 // Team A wins
    };

    // Kills are ignored for the purpose of simulation, since the server controls the kills
    // it can be assumed that they are enforced as they should

    // Distibute the winnings
    await program.methods
      .distributeWinnings(distributeArgs)
      .accountsPartial({
        globalConfig: globalConfigKey,
        server: gameServerKeypair.publicKey,
        creator: user1.publicKey,
        creatorTokenAccount: user1TokenAccount,
        gameSession: gameSessionKey,
      })
      .remainingAccounts([
        // Team A winners in order: user1, user3, user5
        { pubkey: user1.publicKey, isSigner: false, isWritable: true },
        { pubkey: user1TokenAccount, isSigner: false, isWritable: true },
        { pubkey: user3.publicKey, isSigner: false, isWritable: true },
        { pubkey: user3TokenAccount, isSigner: false, isWritable: true },
        { pubkey: user5.publicKey, isSigner: false, isWritable: true },
        { pubkey: user5TokenAccount, isSigner: false, isWritable: true }
      ])
      .signers([gameServerKeypair])
      .rpc(confirmOptions);

    console.log("Final balances:- \n\n");
    const finalBalances: number[] = [];
    for (let i = 1; i <= 6; i++) {
      const tokenAccount = eval(`user${i}TokenAccount`) as PublicKey;
      const balance = await getTokenBalance(provider.connection, tokenAccount);
      finalBalances.push(balance);
      console.log(`User${i}:`, balance);
    }

    // Team A (users 1, 3, 5) should each get 0.1 tokens
    // Team B (users 2, 4, 6) should each lose 0.1 tokens
    assert.equal(finalBalances[0] - initialBalances[0], 100000000); // user1: + 0.1
    assert.equal(finalBalances[1] - initialBalances[1], -100000000); // user2: - 0.1
    assert.equal(finalBalances[2] - initialBalances[2], 100000000); // user3: + 0.1
    assert.equal(finalBalances[3] - initialBalances[3], -100000000); // user4: - 0.1
    assert.equal(finalBalances[4] - initialBalances[4], 100000000); // user5: + 0.1
    assert.equal(finalBalances[5] - initialBalances[5], -100000000); // user6: - 0.1
  });

  it("Successfully distributes pay-to-spawn earnings in 1v1", async () => {
    const sessionId = getSessionId(33);

    const gameSessionKey = getGameSessionKey(program.programId, sessionId);

    const vaultKey = getVaultKey(program.programId, sessionId);

    const vaultTokenAccountKey = getVaultTokenAccount(mintKey, vaultKey);

    console.log("Initial balances:-\n\n");
    const user1InitialBalance = await getTokenBalance(provider.connection, user1TokenAccount);
    const user2InitialBalance = await getTokenBalance(provider.connection, user2TokenAccount);

    console.log("User 1:-", user1InitialBalance);
    console.log("User 2:-", user2InitialBalance);

    // Arguments for the `create_game_session` instruction
    const createGameSessionArgs: types.CreateGameSessionArgs = {
      sessionId: sessionId,
      wagerAmount: wagerAmount,
      gameMode: { payToSpawnOneVsOne: {} },
      creatorTeam: 0,
      creatorIndex:0,
      teamA: [user1.publicKey],
      teamB: []
    };

    // Create the game session and join user1
    await program.methods
      .createGameSession(createGameSessionArgs)
      .accountsPartial({
        user: user1.publicKey,
        gameSession: gameSessionKey,
        userTokenAccount: user1TokenAccount,
        mint: mintKey
      })
      .signers([user1])
      .rpc(confirmOptions);

    // Arguments for the `join_user` instruction
    const joinArgs: types.JoinUserArgs = {
      team: 1
    };

    // Join user2
    await program.methods
      .joinUser(joinArgs)
      .accountsPartial({
        user: user2.publicKey,
        gameSession: gameSessionKey,
        userTokenAccount: user2TokenAccount,
        mint: mintKey
      })
      .signers([user2])
      .rpc(confirmOptions);

    console.log("Before distribution - Vault balance:-", 
      await getTokenBalance(provider.connection, vaultTokenAccountKey));

    // Arguments for the `record_kill` instruction
    const recordKillArgs:types.RecordKillArgs = {
      killerTeam:0,
      killerIndex:0,
      killer:user1.publicKey,
      victimTeam:1,
      victimIndex:0,
      victim:user2.publicKey,      
    }

    // Simulate kills to adjust user1's and user2's earnings
    for (let i = 0; i < 10; i++) {
      await program.methods
        .recordKill(recordKillArgs)
        .accountsPartial({
          globalConfig: globalConfigKey,
          gameSession: gameSessionKey,
          server:gameServerKeypair.publicKey
        })
        .signers([gameServerKeypair])
        .rpc(confirmOptions);
    }

    // After user2 has been killed that many times all of their earnings should go
    // to user1

    // Distribute the winnings
    await program.methods
      .distributePayToSpawnWinnings()
      .accountsPartial({
        globalConfig: globalConfigKey,
        server: gameServerKeypair.publicKey,
        creator: user1.publicKey,
        creatorTokenAccount: user1TokenAccount,
        gameSession: gameSessionKey
      })
      .remainingAccounts([
        { pubkey: user1.publicKey, isSigner: false, isWritable: true },
        { pubkey: user1TokenAccount, isSigner: false, isWritable: true },
        { pubkey: user2.publicKey, isSigner: false, isWritable: true },
        { pubkey: user2TokenAccount, isSigner: false, isWritable: true }
      ])
      .signers([gameServerKeypair])
      .rpc(confirmOptions);

    console.log("Final balances:- \n\n");
    const user1FinalBalance = await getTokenBalance(provider.connection, user1TokenAccount);

    const user2FinalBalance = await getTokenBalance(provider.connection, user2TokenAccount);

    console.log("User 1:-", user1FinalBalance);

    console.log("User 2:-", user2FinalBalance);

    // User1 should have won the other wager and got 0.1 tokens
    assert.equal(user1FinalBalance - user1InitialBalance, 100000000); // + 0.1 tokens
    assert.equal(user2FinalBalance - user2InitialBalance, -100000000); // - 0.1 tokens
  });

  it("Successfully distributes pay-to-spawn earnings in 3v3", async () => {
    const sessionId = getSessionId(34);

    const gameSessionKey = getGameSessionKey(program.programId, sessionId);

    const vaultKey = getVaultKey(program.programId, sessionId);

    const vaultTokenAccountKey = getVaultTokenAccount(mintKey, vaultKey);

    // Save initial balances
    const initialBalances: Record<string, number> = {};
    for (let i = 1; i <= 6; i++) {
      const tokenAccount = eval(`user${i}TokenAccount`) as PublicKey;
      initialBalances[`user${i}`] = await getTokenBalance(provider.connection, tokenAccount);
    }

    // Save creator balance
    const initialCreatorBalance = await getTokenBalance(provider.connection, user1TokenAccount);

    // Sort to reduce lamports(gas) spent
    const [index, teamA] = getSortedAndCreatorIndex([user1.publicKey, user3.publicKey, user5.publicKey]);
    const teamB = getSortedAndCreatorIndex([user2.publicKey, user4.publicKey, user6.publicKey])[1];

    // Arguments for the `create_game_session` instruction
    const createGameSessionArgs: types.CreateGameSessionArgs = {
      sessionId,
      wagerAmount,
      gameMode: { payToSpawnThreeVsThree: {} },
      creatorTeam: 0,
      creatorIndex: index,
      teamA,
      teamB
    };

    // Create the game session
    await program.methods
      .createGameSession(createGameSessionArgs)
      .accountsPartial({
        user: user1.publicKey,
        gameSession: gameSessionKey,
        vault: vaultKey,
        userTokenAccount: user1TokenAccount,
        mint: mintKey,
      })
      .signers([user1])
      .rpc(confirmOptions);

    // Join remaining users
    const joinConfigs = [
      { user: user2, tokenAccount: user2TokenAccount, team: 1 },
      { user: user3, tokenAccount: user3TokenAccount, team: 0 },
      { user: user4, tokenAccount: user4TokenAccount, team: 1 },
      { user: user5, tokenAccount: user5TokenAccount, team: 0 },
      { user: user6, tokenAccount: user6TokenAccount, team: 1 },
    ];

    for (const { user, tokenAccount, team } of joinConfigs) {
      await program.methods
        .joinUser({ team })
        .accountsPartial({
          user: user.publicKey,
          gameSession: gameSessionKey,
          userTokenAccount: tokenAccount,
          mint: mintKey,
          vault:vaultKey
        })
        .signers([user])
        .rpc(confirmOptions);
    }

    // Record kills helper
    async function doKills(
      killerTeam: number,
      killerIndex: number,
      victimTeam: number,
      victimIndex: number,
      times: number,
      killerPubkey: PublicKey,
      victimPubkey: PublicKey
    ) {
      const args: types.RecordKillArgs = {
        killerTeam,
        killerIndex,
        killer: killerPubkey,
        victimTeam,
        victimIndex,
        victim: victimPubkey,
      };

      for (let i = 0; i < times; i++) {
        await program.methods
          .recordKill(args)
          .accountsPartial({
            globalConfig: globalConfigKey,
            gameSession: gameSessionKey,
            server: gameServerKeypair.publicKey,
          })
          .signers([gameServerKeypair])
          .rpc(confirmOptions);
      }
    }

    // Run 6 random kill configurations
    for (let i = 0; i < 6; i++) {
      const [killerTeam, killerIndex, victimIndex, killsCount] = generateRandomKillTuple(2, 3); 
      // playerUpperBound = 2 → because each team has 3 players (indices 0..2)
      // killsUpperBound = 3 → max kills per event

      const killer = killerTeam === 0
        ? [user1.publicKey, user3.publicKey, user5.publicKey][killerIndex]
        : [user2.publicKey, user4.publicKey, user6.publicKey][killerIndex];

      const victim = killerTeam === 0
        ? [user2.publicKey, user4.publicKey, user6.publicKey][victimIndex]
        : [user1.publicKey, user3.publicKey, user5.publicKey][victimIndex];

      const victimTeam = killerTeam === 0 ? 1 : 0;

      console.log(
        `Random kill ${i + 1}: Team ${killerTeam} player[${killerIndex}] (${killer.toBase58()}) → ` +
        `Team ${victimTeam} player[${victimIndex}] (${victim.toBase58()}) x${killsCount}`
      );

      await doKills(killerTeam, killerIndex, victimTeam, victimIndex, killsCount, killer, victim);
    }

    // Fetch game session before distribution
    const gameSessionBefore: any = await program.account.gameSession.fetch(gameSessionKey);

    // Distribute winnings
    await program.methods
      .distributePayToSpawnWinnings()
      .accountsPartial({
        globalConfig: globalConfigKey,
        server: gameServerKeypair.publicKey,
        creator: user1.publicKey,
        creatorTokenAccount: user1TokenAccount,
        gameSession: gameSessionKey,
        vault:vaultKey
      })
      .remainingAccounts([
        { pubkey: user1.publicKey, isSigner: false, isWritable: true },
        { pubkey: user1TokenAccount, isSigner: false, isWritable: true },
        { pubkey: user3.publicKey, isSigner: false, isWritable: true },
        { pubkey: user3TokenAccount, isSigner: false, isWritable: true },
        { pubkey: user5.publicKey, isSigner: false, isWritable: true },
        { pubkey: user5TokenAccount, isSigner: false, isWritable: true },
      ])
      .signers([gameServerKeypair])
      .rpc(confirmOptions);

    // Fetch game session after distribution
    const gameSessionAfter: any = await program.account.gameSession.fetch(gameSessionKey);

    // Save final balances
    const finalBalances: Record<string, number> = {};
    for (let i = 1; i <= 6; i++) {
      const tokenAccount = eval(`user${i}TokenAccount`) as PublicKey;
      finalBalances[`user${i}`] = await getTokenBalance(provider.connection, tokenAccount);
    }
    const finalCreatorBalance = await getTokenBalance(provider.connection, user1TokenAccount);

    const players = extractPlayerStats(gameSessionBefore);

    const { earnings, leftover } = calculateExpectedEarnings(gameSessionBefore, players);

    for (let i = 1; i <= 6; i++) {
      const pubkey = eval(`user${i}.publicKey`) as PublicKey;
      const pkStr = pubkey.toBase58();
      const expected = earnings[pkStr] ?? 0;
      const delta = finalBalances[`user${i}`] - initialBalances[`user${i}`];
      assert.equal(delta, expected, `User${i} should have earned ${expected}, got ${delta}`);
    }

    // Creator = earnings + leftover
    const creatorPk = user1.publicKey.toBase58();
    const expectedCreator = (earnings[creatorPk] ?? 0) + leftover;
    const deltaCreator = finalCreatorBalance - initialCreatorBalance;
    assert.equal(deltaCreator, expectedCreator, `Creator should have earned ${expectedCreator}, got ${deltaCreator}`);
  });


  it("Fails to distribute winnings when game not in progress", async () => {
    const sessionId = getSessionId(5);

    const gameSessionKey = getGameSessionKey(program.programId, sessionId);

    const vaultKey = getVaultKey(program.programId, sessionId);

    const vaultTokenAccountKey = getVaultTokenAccount(mintKey, vaultKey);

    console.log("Initial balances:-\n\n");
    console.log("User 1:-", await getTokenBalance(provider.connection, user1TokenAccount));

    // Arguments for the `create_game_session` instruction
    const createGameSessionArgs: types.CreateGameSessionArgs = {
      sessionId: sessionId,
      wagerAmount: wagerAmount,
      gameMode: { winnerTakesAllOneVsOne: {} },
      creatorTeam: 0, // Team A
      creatorIndex:0,
      teamA: [user1.publicKey],
      teamB: []
    };

    // Execute the transaction
    await program.methods
      .createGameSession(createGameSessionArgs)
      .accountsPartial({
        user: user1.publicKey,
        gameSession: gameSessionKey,
        userTokenAccount: user1TokenAccount,
        mint: mintKey
      })
      .signers([user1])
      .rpc(confirmOptions);

    console.log("After create - Vault balance:- ", 
      await getTokenBalance(provider.connection, vaultTokenAccountKey));

    // Arguments for the `distribute_winnings` instruction
    const distributeArgs: types.DistributeWinningsArgs = {
      winningTeam: 0 // Team A wins
    };

    try {
      // Try to execute the transaction - should fail
      await program.methods
        .distributeWinnings(distributeArgs)
        .accountsPartial({
          globalConfig: globalConfigKey,
          server: gameServerKeypair.publicKey,
          creator: user1.publicKey,
          creatorTokenAccount: user1TokenAccount,
          gameSession: gameSessionKey,
          vault:vaultKey          
        })
        .remainingAccounts([
          {
            pubkey: user1.publicKey,
            isSigner: false,
            isWritable: true,
          },
          {
            pubkey: user1TokenAccount,
            isSigner: false,
            isWritable: true,
          }
        ])
        .signers([gameServerKeypair])
        .rpc(confirmOptions);

      assert.fail("The transaction should have failed the game is not in progress");
    } catch (err) {
        assert(err instanceof anchor.AnchorError, "Unknown error");
      
        const anchorError = err;
      
        assert.equal(anchorError.error.errorCode.code, "GameNotInProgress");
    }
  });

  it("Fails to distribute winnings with wrong remaining accounts count", async () => {
    const sessionId = getSessionId(6);

    const gameSessionKey = getGameSessionKey(program.programId, sessionId);

    const vaultKey = getVaultKey(program.programId, sessionId);

    const vaultTokenAccountKey = getVaultTokenAccount(mintKey, vaultKey);

    console.log("Initial balances:-\n\n");
    console.log("User 1:-", await getTokenBalance(provider.connection, user1TokenAccount));
    console.log("User 2:-", await getTokenBalance(provider.connection, user2TokenAccount));

    // Arguments for the `create_game_session` instruction
    const createGameSessionArgs: types.CreateGameSessionArgs = {
      sessionId: sessionId,
      wagerAmount: wagerAmount,
      gameMode: { winnerTakesAllOneVsOne: {} },
      creatorTeam: 0, // Team A
      creatorIndex:0,
      teamA: [user1.publicKey],
      teamB: []
    };

    // Execute the transaction
    await program.methods
      .createGameSession(createGameSessionArgs)
      .accountsPartial({
        user: user1.publicKey,
        gameSession: gameSessionKey,
        userTokenAccount: user1TokenAccount,
        mint: mintKey
      })
      .signers([user1])
      .rpc(confirmOptions);

    // Arguments for the `join_user` instruction
    const joinArgs: types.JoinUserArgs = {
      team: 1 // Team B
    };

    // Execute the transaction
    await program.methods
      .joinUser(joinArgs)
      .accountsPartial({
        user: user2.publicKey,
        gameSession: gameSessionKey,
        userTokenAccount: user2TokenAccount,
        mint: mintKey,
          vault:vaultKey        
      })
      .signers([user2])
      .rpc(confirmOptions);

    console.log("After joins - Vault balance:- ", 
      await getTokenBalance(provider.connection, vaultTokenAccountKey));

    // Arguments for the `distribute_winnings` instruction
    const distributeArgs: types.DistributeWinningsArgs = {
      winningTeam: 0 // Team A wins
    };

    try {
      // Try to execute the transaction with wrong remaining accounts - should fail
      await program.methods
        .distributeWinnings(distributeArgs)
        .accountsPartial({
          globalConfig: globalConfigKey,
          server: gameServerKeypair.publicKey,
          creator: user1.publicKey,
          creatorTokenAccount: user1TokenAccount,
          gameSession: gameSessionKey,
          vault:vaultKey          
        })
        .remainingAccounts([
          // Wrong count - only player, missing token account
          { pubkey: user1.publicKey, isSigner: false, isWritable: true }
        ])
        .signers([gameServerKeypair])
        .rpc(confirmOptions);

      assert.fail("The transaction should have failed, the remaining accounts are not complete.");
    } catch (err) {
       assert(err instanceof anchor.AnchorError, "Unknown error");
      
        const anchorError = err;
      
        assert.equal(anchorError.error.errorCode.code, "InvalidRemainingAccounts");
    }
  });
});