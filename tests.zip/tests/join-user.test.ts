import * as anchor from "@coral-xyz/anchor";
import { Program } from "@coral-xyz/anchor";
import * as types from "./types";
import { WagerProgram } from "../app/src/app/types/wager_program";
import { BN } from "@coral-xyz/anchor";
import { PublicKey, Keypair, ConfirmOptions } from "@solana/web3.js";
import { assert } from "chai";
import {
  getGameSessionKey,
  getVaultKey,
  getVaultTokenAccount,
  setupTokenAccount,
  airdropToAccounts,
  getTokenBalance,
  getSessionId,
  getGlobalConfigKey,
  getGameServerKeypair,
  getMintKey,
  getSortedAndCreatorIndex,
} from "./utils";

const confirmOptions: ConfirmOptions = { commitment: "confirmed" };

describe("Join User", () => {
  // Set up the environment
  const provider = anchor.AnchorProvider.env();

  anchor.setProvider(provider);

  const program = anchor.workspace.WagerProgram as Program<WagerProgram>;

  // Get the mint and game server
  const mintKey = getMintKey();

  let gameServerKeypair:Keypair;

  const wagerAmount = new BN(100_000_000); // 0.1 tokens

  // Test users
  const user1 = Keypair.generate();
  const user2 = Keypair.generate();
  const user3 = Keypair.generate();
  const user4 = Keypair.generate();
  const user5 = Keypair.generate();
  const user6 = Keypair.generate();
  const user7 = Keypair.generate();

  let user1TokenAccount: PublicKey;
  let user2TokenAccount: PublicKey;
  let user3TokenAccount: PublicKey;
  let user4TokenAccount: PublicKey;
  let user5TokenAccount: PublicKey;
  let user6TokenAccount: PublicKey;
  let user7TokenAccount: PublicKey;

  before(async () => {

    gameServerKeypair = getGameServerKeypair();

    console.log("Server: ", gameServerKeypair.publicKey);

    await airdropToAccounts(provider.connection, [
      gameServerKeypair.publicKey,
      user1.publicKey,
      user2.publicKey,
      user3.publicKey,
      user4.publicKey,
      user5.publicKey,
      user6.publicKey,
      user7.publicKey
    ]);

    const initialMintAmount = 1_000_000_000; 

    user1TokenAccount = await setupTokenAccount(provider.connection, gameServerKeypair, mintKey, user1.publicKey, initialMintAmount);
    user2TokenAccount = await setupTokenAccount(provider.connection, gameServerKeypair, mintKey, user2.publicKey, initialMintAmount);
    user3TokenAccount = await setupTokenAccount(provider.connection, gameServerKeypair, mintKey, user3.publicKey, initialMintAmount);
    user4TokenAccount = await setupTokenAccount(provider.connection, gameServerKeypair, mintKey, user4.publicKey, initialMintAmount);
    user5TokenAccount = await setupTokenAccount(provider.connection, gameServerKeypair, mintKey, user5.publicKey, initialMintAmount);
    user6TokenAccount = await setupTokenAccount(provider.connection, gameServerKeypair, mintKey, user6.publicKey, initialMintAmount);
    user7TokenAccount = await setupTokenAccount(provider.connection, gameServerKeypair, mintKey, user7.publicKey, wagerAmount.div(new BN(2)).toNumber());

  });

  it("Successfully allows players to join game", async () => {
    const sessionId = getSessionId(41);

    const gameSessionKey = getGameSessionKey(program.programId, sessionId);

    const vaultKey = getVaultKey(program.programId, sessionId);

    // Sort the team to reduce lamports spent and get the creator index
    const [index, teamA] = getSortedAndCreatorIndex([user1.publicKey, user3.publicKey, user5.publicKey]);

    const createArgs: types.CreateGameSessionArgs = {
      sessionId,
      wagerAmount,
      gameMode: { winnerTakesAllThreeVsThree: {} },
      creatorTeam: 0,
      creatorIndex: index,
      teamA,
      teamB: [],
    };

    // Create the game session
    await program.methods
      .createGameSession(createArgs)
      .accountsPartial({
        user: user1.publicKey,
        gameSession: gameSessionKey,
        userTokenAccount: user1TokenAccount,
        mint: mintKey,
      })
      .signers([user1])
      .rpc(confirmOptions);

    const joinConfigs = [
      { user: user2, tokenAccount: user2TokenAccount, team: 1 },
      { user: user3, tokenAccount: user3TokenAccount, team: 0 },
      { user: user4, tokenAccount: user4TokenAccount, team: 1 },
      { user: user5, tokenAccount: user5TokenAccount, team: 0 },
      { user: user6, tokenAccount: user6TokenAccount, team: 1 },
    ];

    // Join all the users into the team
    for (const config of joinConfigs) {
      await program.methods
        .joinUser({ team: config.team })
        .accountsPartial({
          user: config.user.publicKey,
          gameSession: gameSessionKey,
          userTokenAccount: config.tokenAccount,
          mint: mintKey,
          vault:vaultKey          
        })
        .signers([config.user])
        .rpc(confirmOptions);
    }

    {
      const gameSession = await program.account.gameSession.fetch(gameSessionKey);
      console.log("Game session: \n\n",gameSession);

      const teamA = gameSession.teamA;
      const teamB = gameSession.teamB;

      const aPlayers = (teamA.players as PublicKey[]).map((p) => p.toBase58());
      const bPlayers = (teamB.players as PublicKey[]).map((p) => p.toBase58());

      // Ensure players are present in the expected teams
      assert.include(aPlayers, user1.publicKey.toBase58(), "user1 should be in teamA");
      assert.include(aPlayers, user3.publicKey.toBase58(), "user3 should be in teamA");
      assert.include(aPlayers, user5.publicKey.toBase58(), "user5 should be in teamA");

      assert.include(bPlayers, user2.publicKey.toBase58(), "user2 should be in teamB");
      assert.include(bPlayers, user4.publicKey.toBase58(), "user4 should be in teamB");
      assert.include(bPlayers, user6.publicKey.toBase58(), "user6 should be in teamB");

      assert.deepEqual(gameSession.status, {inProgress:{}}, "Game status should be in progress once filled");
    }
  });

  it("Fails to join when the target team is already full", async () => {
    const sessionId = getSessionId(42);

    const gameSessionKey = getGameSessionKey(program.programId, sessionId);

    const vaultKey = getVaultKey(program.programId, sessionId);

    // Sort the team to reduce lamports spent and get the creator index
    const [index, teamA] = getSortedAndCreatorIndex([user1.publicKey, user3.publicKey, user5.publicKey]);


    const createArgs: types.CreateGameSessionArgs = {
      sessionId,
      wagerAmount,
      gameMode: { winnerTakesAllThreeVsThree: {} },
      creatorTeam: 0,
      creatorIndex: index,
      teamA,
      teamB: [],
    };

    // Create the game session
    await program.methods
      .createGameSession(createArgs)
      .accountsPartial({
        user: user1.publicKey,
        gameSession: gameSessionKey,
        vault: vaultKey,
        userTokenAccount: user1TokenAccount,
        mint: mintKey,
      })
      .signers([user1])
      .rpc(confirmOptions);

    // Join the users
    await program.methods
      .joinUser({ team: 0 })
      .accountsPartial({
        user: user3.publicKey,
        gameSession: gameSessionKey,
        userTokenAccount: user3TokenAccount,
        mint: mintKey,
        vault: vaultKey
      })
      .signers([user3])
      .rpc(confirmOptions);

    await program.methods
      .joinUser({ team: 0 })
      .accountsPartial({
        user: user5.publicKey,
        gameSession: gameSessionKey,
        userTokenAccount: user5TokenAccount,
        mint: mintKey
      })
      .signers([user5])
      .rpc(confirmOptions);

    // Attempt to join an extra user to teamA
    try {
      await program.methods
        .joinUser({ team: 0 })
        .accountsPartial({
          user: user2.publicKey,
          gameSession: gameSessionKey,
          userTokenAccount: user2TokenAccount,
          mint: mintKey,
          vault: vaultKey,
        })
        .signers([user2])
        .rpc(confirmOptions);

      assert.fail("The transaction should have falied with TeamIsFull but it succeeded");
    } catch (err: any) {
      assert(err instanceof anchor.AnchorError, "Unknown error");

      const anchorError = err;
      
      assert.equal(anchorError.error.errorCode.code, "TeamIsFull");
    }
  });

  it("Fails to join when the team was completely reserved at session creation", async () => {
    const sessionId = getSessionId(43);

    const gameSessionKey = getGameSessionKey(program.programId, sessionId);

    const vaultKey = getVaultKey(program.programId, sessionId);

    const vaultTokenAccountKey = getVaultTokenAccount(mintKey, vaultKey);

    // Sort the team to reduce lamports spent and get the creator index
    const [index, teamA] = getSortedAndCreatorIndex([user1.publicKey, user3.publicKey, user5.publicKey]);

    const createArgs: types.CreateGameSessionArgs = {
      sessionId,
      wagerAmount,
      gameMode: { winnerTakesAllThreeVsThree: {} },
      creatorTeam: 0,
      creatorIndex: index,
      teamA,
      teamB: [],
    };

    // Create the game session    
    await program.methods
      .createGameSession(createArgs)
      .accountsPartial({
        user: user1.publicKey,
        gameSession: gameSessionKey,
        vault: vaultKey,
        userTokenAccount: user1TokenAccount,
        mint: mintKey,
      })
      .signers([user1])
      .rpc(confirmOptions);

    // Try to join a user not among the reserved
    try {
      await program.methods
        .joinUser({ team: 0 })
        .accountsPartial({
          user: user4.publicKey,
          gameSession: gameSessionKey,
          userTokenAccount: user4TokenAccount,
          mint: mintKey,
          vault: vaultKey,
          vaultTokenAccount: vaultTokenAccountKey,
        })
        .signers([user4])
        .rpc(confirmOptions);

      assert.fail("The transaction should have falied with TeamIsFull but it succeeded");
    } catch (err: any) {
      assert(err instanceof anchor.AnchorError, "Unknown error");

      const anchorError = err;

      assert.equal(anchorError.error.errorCode.code, "TeamIsFull");
    }
  });

  it("Fails when the same player attempts to join the same team twice", async () => {
    const sessionId = getSessionId(44);

    const gameSessionKey = getGameSessionKey(program.programId, sessionId);

    const vaultKey = getVaultKey(program.programId, sessionId);

    // Sort the team to reduce lamports spent and get the creator index
    const [index, teamA] = getSortedAndCreatorIndex([user1.publicKey, user3.publicKey, user5.publicKey]);

    console.log("Team A: ", teamA);

    const createArgs: types.CreateGameSessionArgs = {
      sessionId,
      wagerAmount,
      gameMode: { winnerTakesAllThreeVsThree: {} },
      creatorTeam: 0,
      creatorIndex: index,
      teamA,
      teamB: [],
    };
    await program.methods
      .createGameSession(createArgs)
      .accountsPartial({
        user: user1.publicKey,
        gameSession: gameSessionKey,
        vault: vaultKey,
        userTokenAccount: user1TokenAccount,
        mint: mintKey,
      })
      .signers([user1])
      .rpc(confirmOptions);

    await program.methods
      .joinUser({ team: 0 })
      .accountsPartial({
        user: user3.publicKey,
        gameSession: gameSessionKey,
        userTokenAccount: user3TokenAccount,
        mint: mintKey
      })
      .signers([user3])
      .rpc(confirmOptions);

    // user3 attempts to join teamA again 
    try {
      await program.methods
        .joinUser({ team: 0 })
        .accountsPartial({
          user: user3.publicKey,
          gameSession: gameSessionKey,
          userTokenAccount: user3TokenAccount,
          mint: mintKey,
          vault: vaultKey,
        })
        .signers([user3])
        .rpc(confirmOptions);

      assert.fail("The transaction should have falied with PlayerAlreadyInGame but it succeeded");
    } catch (err: any) {
      assert(err instanceof anchor.AnchorError, "Unknown error");

      const anchorError = err;

      assert.equal(anchorError.error.errorCode.code, "PlayerAlreadyInGame");
    }
  });

  it("Fails when a player who already joined team B attempts to join team A", async () => {
    const sessionId = getSessionId(45);

    const gameSessionKey = getGameSessionKey(program.programId, sessionId);

    const vaultKey = getVaultKey(program.programId, sessionId);

    const vaultTokenAccountKey = getVaultTokenAccount(mintKey, vaultKey);

    const createArgs: types.CreateGameSessionArgs = {
      sessionId,
      wagerAmount,
      gameMode: { winnerTakesAllThreeVsThree: {} },
      creatorTeam: 0,
      creatorIndex:0,
      teamA: [user1.publicKey],
      teamB: [],
    };

    await program.methods
      .createGameSession(createArgs)
      .accountsPartial({
        user: user1.publicKey,
        gameSession: gameSessionKey,
        vault: vaultKey,
        userTokenAccount: user1TokenAccount,
        mint: mintKey,
      })
      .signers([user1])
      .rpc(confirmOptions);

    await program.methods
      .joinUser({ team: 1 })
      .accountsPartial({
        user: user2.publicKey,
        gameSession: gameSessionKey,
        userTokenAccount: user2TokenAccount,
        mint: mintKey
      })
      .signers([user2])
      .rpc(confirmOptions);

    // Same user tries to join the other team
    try {
      await program.methods
        .joinUser({ team: 0 })
        .accountsPartial({
          user: user2.publicKey,
          gameSession: gameSessionKey,
          userTokenAccount: user2TokenAccount,
          mint: mintKey,
          vault: vaultKey,
          vaultTokenAccount: vaultTokenAccountKey,
        })
        .signers([user2])
        .rpc(confirmOptions);

      assert.fail("The transaction should have falied with PlayerAlreadyInGame but it succeeded");
    } catch (err: any) {
      assert(err instanceof anchor.AnchorError, "Unknown error");

      const anchorError = err;

      assert.equal(anchorError.error.errorCode.code, "PlayerAlreadyInGame");
    }
  });

  it("Fails when attempting to join after the game is no longer waiting for players", async () => {
    const sessionId = getSessionId(46);

    const gameSessionKey = getGameSessionKey(program.programId, sessionId);

    const vaultKey = getVaultKey(program.programId, sessionId);

    const vaultTokenAccountKey = getVaultTokenAccount(mintKey, vaultKey);

    const createArgs: types.CreateGameSessionArgs = {
      sessionId,
      wagerAmount,
      gameMode: { winnerTakesAllOneVsOne: {} },
      creatorTeam: 0,
      creatorIndex:0,
      teamA: [user1.publicKey],
      teamB: [],
    };

    await program.methods
      .createGameSession(createArgs)
      .accountsPartial({
        user: user1.publicKey,
        gameSession: gameSessionKey,
        vault: vaultKey,
        userTokenAccount: user1TokenAccount,
        mint: mintKey,
      })
      .signers([user1])
      .rpc(confirmOptions);

    await program.methods
      .joinUser({ team: 1 })
      .accountsPartial({
        user: user2.publicKey,
        gameSession: gameSessionKey,
        userTokenAccount: user2TokenAccount,
        mint: mintKey
      })
      .signers([user2])
      .rpc(confirmOptions);

    const gameSession = await program.account.gameSession.fetch(gameSessionKey);
    assert.deepEqual(gameSession.status, {inProgress:{}}, "Game status should be in progess'");

    try {
      await program.methods
        .joinUser({ team: 0 })
        .accountsPartial({
          user: user3.publicKey,
          gameSession: gameSessionKey,
          userTokenAccount: user3TokenAccount,
          mint: mintKey,
          vault: vaultKey,
          vaultTokenAccount: vaultTokenAccountKey,
        })
        .signers([user3])
        .rpc(confirmOptions);

      assert.fail("The transaction should have falied with GameInProgress but it succeeded");
    } catch (err: any) {
      assert(err instanceof anchor.AnchorError, "Unknown error");
      const anchorError = err;
      assert.equal(anchorError.error.errorCode.code, "GameInProgress");
    }
  });


  it("User fails to join with insufficent funds ", async () => {
    const sessionId = getSessionId(47);

    const gameSessionKey = getGameSessionKey(program.programId, sessionId);

    const vaultKey = getVaultKey(program.programId, sessionId);

    const createGameSessionArgs:types.CreateGameSessionArgs = {
      sessionId:sessionId, 
      wagerAmount:wagerAmount, 
      gameMode:{ payToSpawnOneVsOne: {} },
      creatorTeam:0,
      creatorIndex:0,
      teamA:[user1.publicKey],
      teamB:[]
    }

    // Create game session and join user1
    await program.methods
      .createGameSession(createGameSessionArgs)
      .accountsPartial({
        user:user1.publicKey,
        gameSession: gameSessionKey,
        vault: vaultKey,
        userTokenAccount: user1TokenAccount,
        mint: mintKey
      })
      .signers([user1])
      .rpc(confirmOptions);

      
      try{
        // Join user7 (Team B)
        // This should fail, the user's balance is not sufficient
        await program.methods
          .joinUser({ team: 1 })
          .accountsPartial({
            user: user7.publicKey,
            gameSession: gameSessionKey,
            vault: vaultKey,
            userTokenAccount: user7TokenAccount,
            mint: mintKey,
          })
          .signers([user7])
          .rpc(confirmOptions);

        assert.fail("This transaction should have failed the user's funds were not sufficient")
    } catch(err){
        assert.include(err.message, "insufficient funds")
    }
  });


});
