import * as anchor from "@coral-xyz/anchor";
import { Program } from "@coral-xyz/anchor";
import { WagerProgram } from "../app/src/app/types/wager_program";
import *  as types from "./types";
import { BN } from "@coral-xyz/anchor";
import { assert } from "chai";
import {
  getSessionId,
  getGameSessionKey,
  getVaultKey,
  getMintKey,
  getGameServerKeypair,
  getSortedAndCreatorIndex,
  airdropToAccounts,
  setupTokenAccount,
} from "./utils";
import { 
  ConfirmOptions, 
  Keypair, 
  PublicKey,
  LAMPORTS_PER_SOL 
} from "@solana/web3.js";
import {
  createMint
} from "@solana/spl-token";

const confirmOptions: ConfirmOptions = { commitment: "confirmed" };


describe("Game Session Creation", () => {
  // Setup the environment
  const provider = anchor.AnchorProvider.env();
  anchor.setProvider(provider);

  const program = anchor.workspace.WagerProgram as Program<WagerProgram>;

  // Get the mint and server
  let mintKey = getMintKey();

  // The keypair is set later because it is changed in one of it blocks of the update config
  // test, if it is assigned here it would cause other tests to fail because the top describes
  // are executed before all the 
  let gameServerKeypair:Keypair;
  
  // Test users
  let user1 = Keypair.generate();
  let user2 = Keypair.generate();
  let user3 = Keypair.generate();
  let user4 = Keypair.generate();
  let user5 = Keypair.generate();
  let user6 = Keypair.generate();
  let user1TokenAccount: PublicKey;
  let user2TokenAccount: PublicKey;
  let user3TokenAccount: PublicKey;
  let user4TokenAccount: PublicKey;
  let user5TokenAccount: PublicKey;
  let user6TokenAccount: PublicKey;

  // The amount being bet
  const sessionWager = new BN(100000000); // 0.1 tokens with 9 decimals

  before(async () => {

    gameServerKeypair = getGameServerKeypair();

    await airdropToAccounts(provider.connection, [
         gameServerKeypair.publicKey,
         user1.publicKey,
         user2.publicKey,
         user3.publicKey,
         user4.publicKey,
         user5.publicKey,
         user6.publicKey,
       ]);
   
   
       const initialMintAmount = 1_000_000_000; 

       user1TokenAccount = await setupTokenAccount(provider.connection, gameServerKeypair, mintKey, user1.publicKey, initialMintAmount);
       user2TokenAccount = await setupTokenAccount(provider.connection, gameServerKeypair, mintKey, user2.publicKey, initialMintAmount);
       user3TokenAccount = await setupTokenAccount(provider.connection, gameServerKeypair, mintKey, user3.publicKey, initialMintAmount);
       user4TokenAccount = await setupTokenAccount(provider.connection, gameServerKeypair, mintKey, user4.publicKey, initialMintAmount);
       user5TokenAccount = await setupTokenAccount(provider.connection, gameServerKeypair, mintKey, user5.publicKey, initialMintAmount);
       user6TokenAccount = await setupTokenAccount(provider.connection, gameServerKeypair, mintKey, user6.publicKey, initialMintAmount);
   
  });

  it("Successfully creates a game session with winner-takes-all 1v1 mode", async () => {
    const sessionId = getSessionId(1);

    const gameSessionKey = getGameSessionKey(program.programId, sessionId);

    const vaultKey = getVaultKey(program.programId, sessionId);


    // Arguments for the `create_game_session` instruction
    const createGameSessionArgs:types.CreateGameSessionArgs = {
      sessionId: sessionId,
      wagerAmount:sessionWager,
      gameMode: { winnerTakesAllOneVsOne: {} },
      creatorTeam: 0, // Team A
      creatorIndex:0,      
      teamA: [user1.publicKey],
      teamB: []
    };

    // Create the game session
    await program.methods.
      createGameSession(createGameSessionArgs).
      accountsPartial({
        gameSession: gameSessionKey,
        vault: vaultKey,
        user: user1.publicKey,
        userTokenAccount: user1TokenAccount,
        mint: mintKey
      }).
      signers([user1]).
      rpc(confirmOptions);

    // Get the game session account, and confirm it is the way we created it
    const account = await program.account.gameSession.fetch(gameSessionKey);

    assert.equal(account.sessionId, sessionId);

    assert.equal(account.sessionWager.toString(), sessionWager.toString());

    assert.deepEqual(account.gameMode, { winnerTakesAllOneVsOne: {} });

    assert.deepEqual(account.status, {waitingForPlayers:{}});

    console.log("Game session: ", account);
  });

  it("Successfully creates a game session with winner-takes-all 3v3 mode", async () => {
    const sessionId = getSessionId(2);

    const gameSessionKey = getGameSessionKey(program.programId, sessionId);

    const vaultKey = getVaultKey(program.programId, sessionId);
    

    // Arguments for the `create_game_session` instruction
    // The are only one players in each team so there is no need for 
    // sorting
    const createGameSessionArgs:types.CreateGameSessionArgs = {
      sessionId: sessionId,
      wagerAmount: sessionWager,
      gameMode: { winnerTakesAllThreeVsThree: {} },
      creatorTeam: 1, // Team B
      creatorIndex:0,
      teamA: [user1.publicKey], 
      teamB: [user2.publicKey]
    };

    // Create the game session
    await program.methods
      .createGameSession(createGameSessionArgs)
      .accountsPartial({
        user: user2.publicKey,
        gameSession: gameSessionKey,
        vault: vaultKey,
        userTokenAccount: user2TokenAccount,
        mint: mintKey
      })
      .signers([user2])
      .rpc(confirmOptions);

    // Get the game session account and confirm it is the way we created it
    const account = await program.account.gameSession.fetch(gameSessionKey);

    assert.equal(account.sessionId, sessionId);

    assert.equal(account.sessionWager.toString(), sessionWager.toString());

    assert.deepEqual(account.gameMode, { winnerTakesAllThreeVsThree: {} });

    console.log("Game session: ", account);
  });

  it("Successfully creates a game session with winner-takes-all 5v5 mode", async () => {
    const sessionId = getSessionId(3);

    const gameSessionKey = getGameSessionKey(program.programId, sessionId);

    const vaultKey = getVaultKey(program.programId, sessionId);

    // Sort the team and get the resulting creator index
    const [index, teamA] = getSortedAndCreatorIndex([user1.publicKey, user2.publicKey]);
    
    // Arguments for the `create_game_session` instruction
    const createGameSessionArgs:types.CreateGameSessionArgs = {
      sessionId: sessionId,
      wagerAmount: sessionWager,
      gameMode: { winnerTakesAllFiveVsFive: {} },
      creatorTeam: 0, // Team A
      creatorIndex:index,
      teamA,
      teamB: []
    };

    // Create the game session
    await program.methods
      .createGameSession(createGameSessionArgs)
      .accountsPartial({
        user: user1.publicKey,
        gameSession: gameSessionKey,
        vault: vaultKey,
        userTokenAccount: user1TokenAccount,
        mint: mintKey
      })
      .signers([user1])
      .rpc(confirmOptions);

    // Get the game session account and confirm it is the way we created it
    const account = await program.account.gameSession.fetch(gameSessionKey);

    assert.equal(account.sessionId, sessionId);

    assert.equal(account.sessionWager.toString(), sessionWager.toString());

    assert.deepEqual(account.gameMode, { winnerTakesAllFiveVsFive: {} });

    console.log("Game session: ", account);
  });

  it("Successfully creates a game session with pay-to-spawn 1v1 mode", async () => {
    const sessionId = getSessionId(4);

    const gameSessionKey = getGameSessionKey(program.programId, sessionId);

    const vaultKey = getVaultKey(program.programId, sessionId);


    // Arguments for the `create_game_session` instruction
    // The are only one players in each team so there is no need for 
    // sorting
    const createGameSessionArgs:types.CreateGameSessionArgs = {
      sessionId: sessionId,
      wagerAmount: sessionWager,
      gameMode: { payToSpawnOneVsOne: {} },
      creatorTeam: 0,
      creatorIndex:0,
      teamA: [user2.publicKey],
      teamB: []
    };

    // Create the game session
    await program.methods
      .createGameSession(createGameSessionArgs)
      .accountsPartial({
        user: user2.publicKey,
        gameSession: gameSessionKey,
        vault: vaultKey,
        userTokenAccount: user2TokenAccount,
        mint: mintKey
      })
      .signers([user2])
      .rpc(confirmOptions);

    // Get the game session account and confirm it is the way we created it
    const account = await program.account.gameSession.fetch(gameSessionKey);

    assert.equal(account.sessionId, sessionId);

    assert.equal(account.sessionWager.toString(), sessionWager.toString());

    assert.deepEqual(account.gameMode, { payToSpawnOneVsOne: {} });

    console.log("Game session: ", account);
  });

  it("Successfully creates a game session with pay-to-spawn 3v3 mode", async () => {
    const sessionId = getSessionId(5);

    const gameSessionKey = getGameSessionKey(program.programId, sessionId);

    const vaultKey = getVaultKey(program.programId, sessionId);


    // Arguments for the `create_game_session` instruction
    // The are only one players in each team so there is no need for 
    // sorting    
    const createGameSessionArgs:types.CreateGameSessionArgs = {
      sessionId: sessionId,
      wagerAmount: sessionWager,
      gameMode: { payToSpawnThreeVsThree: {} },
      creatorTeam: 1,
      creatorIndex:0,      
      teamA: [],
      teamB: [user3.publicKey]
    };

    // Create the game session
    await program.methods
      .createGameSession(createGameSessionArgs)
      .accountsPartial({
        user: user3.publicKey,
        gameSession: gameSessionKey,
        vault: vaultKey,
        userTokenAccount: user3TokenAccount,
        mint: mintKey
      })
      .signers([user3])
      .rpc(confirmOptions);

    // Get the game session account and confirm it is the way we created it
    const account = await program.account.gameSession.fetch(gameSessionKey);

    assert.equal(account.sessionId, sessionId);

    assert.equal(account.sessionWager.toString(), sessionWager.toString());

    assert.deepEqual(account.gameMode, { payToSpawnThreeVsThree: {} });

    console.log("Game session: ", account);
  });

  it("Successfully creates a game session with pay-to-spawn 5v5 mode", async () => {
    const sessionId = getSessionId(6);

    const gameSessionKey = getGameSessionKey(program.programId, sessionId);

    const vaultKey = getVaultKey(program.programId, sessionId);


    // Arguments for the `create_game_session` instruction
    // The are only one players in each team so there is no need for 
    // sorting    
    const createGameSessionArgs:types.CreateGameSessionArgs = {
      sessionId: sessionId,
      wagerAmount: sessionWager,
      gameMode: { payToSpawnFiveVsFive: {} },
      creatorTeam: 0,
      creatorIndex:0,      
      teamA: [user1.publicKey],
      teamB: []
    };

    // Create the game session
    await program.methods
      .createGameSession(createGameSessionArgs)
      .accountsPartial({
        user: user1.publicKey,
        gameSession: gameSessionKey,
        vault: vaultKey,
        userTokenAccount: user1TokenAccount,
        mint: mintKey
      })
      .signers([user1])
      .rpc(confirmOptions);

    // Get the game session account and confirm it is the way we created it
    const account = await program.account.gameSession.fetch(gameSessionKey);
    
    assert.equal(account.sessionId, sessionId);

    assert.equal(account.sessionWager.toString(), sessionWager.toString());

    assert.deepEqual(account.gameMode, { payToSpawnFiveVsFive: {} });

    console.log("Game session: ", account);
  });

  it("Rounds wager amount to nearest multiple of 10", async () => {
    const sessionId = getSessionId(7);

    const sessionWager = new BN(123456789); // Should be rounded to 123456780

    const gameSessionKey = getGameSessionKey(program.programId, sessionId);

    const vaultKey = getVaultKey(program.programId, sessionId);


    // Arguments for the `create_game_session` instruction
    // The are only one players in each team so there is no need for 
    // sorting       
    const createGameSessionArgs:types.CreateGameSessionArgs = {
      sessionId: sessionId,
      wagerAmount: sessionWager, // Wager amount is not a multiple of 10
      gameMode: { winnerTakesAllOneVsOne: {} },
      creatorTeam: 0,
      creatorIndex:0,      
      teamA: [user2.publicKey],
      teamB: []
    };

    // Create the game session
    await program.methods
      .createGameSession(createGameSessionArgs)
      .accountsPartial({
        user: user2.publicKey,
        gameSession: gameSessionKey,
        vault: vaultKey,
        userTokenAccount: user2TokenAccount,
        mint: mintKey
      })
      .signers([user2])
      .rpc(confirmOptions);

    // Verify wager was rounded
    const account = await program.account.gameSession.fetch(gameSessionKey);

    assert.equal(account.sessionWager.toString(), "123456780");
  });

  it("Fails to create game session when creator is not in the right team", async () => {
    const sessionId = getSessionId(8);

    const gameSessionKey = getGameSessionKey(program.programId, sessionId);

    const vaultKey = getVaultKey(program.programId, sessionId);


    // Arguments for the `create_game_session` instruction
    // The are only one players in each team so there is no need for 
    // sorting       
    const createGameSessionArgs:types.CreateGameSessionArgs = {
      sessionId: sessionId,
      wagerAmount: sessionWager,
      gameMode: { winnerTakesAllOneVsOne: {} },
      creatorTeam: 0, 
      creatorIndex:0,      
      teamA: [user2.publicKey],
      teamB: [user1.publicKey]
    };

    try {
      await program.methods
        .createGameSession(createGameSessionArgs)
        .accountsPartial({
          user: user1.publicKey,
          gameSession: gameSessionKey,
          vault: vaultKey,
          userTokenAccount: user1TokenAccount,
          mint: mintKey
        })
        .signers([user1])
        .rpc(confirmOptions);
      assert.fail("This transaction should have failed with Should have failed with invalid team selection");
    } catch (err) {
      assert(err instanceof anchor.AnchorError, "Unknown error");

      let anchorError = err;

      assert(anchorError.error.errorCode.code == "InvalidCreatorAccount");
    }
  });

  it("Fails to create duplicate game session", async () => {
    const sessionId = getSessionId(9);

    const gameSessionKey = getGameSessionKey(program.programId, sessionId);

    const vaultKey = getVaultKey(program.programId, sessionId);


    // Create the game session
    // The are only one players in each team so there is no need for 
    // sorting       
    const createGameSessionArgs:types.CreateGameSessionArgs = {
      sessionId: sessionId,
      wagerAmount: sessionWager,
      gameMode: { winnerTakesAllOneVsOne: {} },
      creatorTeam: 0,
      creatorIndex:0,      
      teamA: [user1.publicKey],
      teamB: []
    };

    // First attempt should succeed
    await program.methods
      .createGameSession(createGameSessionArgs)
      .accountsPartial({
        user: user1.publicKey,
        gameSession: gameSessionKey,
        vault: vaultKey,
        userTokenAccount: user1TokenAccount,
        mint: mintKey
      })
      .signers([user1])
      .rpc(confirmOptions);

    // Second attempt with same sessionId should fail
    try {
      await program.methods
        .createGameSession(createGameSessionArgs)
        .accountsPartial({
          user: user1.publicKey,
          gameSession: gameSessionKey,
          vault: vaultKey,
          userTokenAccount: user1TokenAccount,
          mint: mintKey
        })
        .signers([user1])
        .rpc(confirmOptions);
      assert.fail("This transaction should have failed with duplicate session");
    } catch (e) {
      assert.include(e.toString(), "Transaction simulation failed");
    }
  });

  it("Fails to create game session with wrong token mint", async () => {
    const sessionId = getSessionId(10);

    const gameSessionKey = getGameSessionKey(program.programId, sessionId);

    const vaultKey = getVaultKey(program.programId, sessionId);
    
    // Create an entirely new mint (not the expected one)
    const wrongMint = Keypair.generate();

    await createMint(
      provider.connection,
      user1,
      gameServerKeypair.publicKey,
      null,
      9,
      wrongMint
    );

    // Arguments for the `create_game_session` instruction
    // The are only one players in each team so there is no need for 
    // sorting   
    const createGameSessionArgs:types.CreateGameSessionArgs = {
      sessionId: sessionId,
      wagerAmount: sessionWager,
      gameMode: { winnerTakesAllOneVsOne: {} },
      creatorTeam: 0,
      creatorIndex:0,      
      teamA: [user1.publicKey],
      teamB: []
    };

    try {
      await program.methods
        .createGameSession(createGameSessionArgs)
        .accountsPartial({
          user: user1.publicKey,
          gameSession: gameSessionKey,
          vault: vaultKey,
          userTokenAccount: user1TokenAccount,
            mint: wrongMint.publicKey, // Invalid mint here
        })
        .signers([user1])
        .rpc(confirmOptions);
      assert.fail("This transaction should have failed with invalid mint");
    } catch (e) {
      assert.include(e.toString(), "InvalidMint");
    }
  });

  it("Fails to create game session with unsorted reserved players", async () => {
    const sessionId = getSessionId(11);

    const gameSessionKey = getGameSessionKey(program.programId, sessionId);

    const vaultKey = getVaultKey(program.programId, sessionId);

    // Sort the team and get the creator index
    const [index, teamA] = getSortedAndCreatorIndex([user1.publicKey, user2.publicKey]);
    
    // Arguments for the `create_game_session` instruction     
    const createGameSessionArgs:types.CreateGameSessionArgs = {
      sessionId: sessionId,
      wagerAmount: sessionWager,
      gameMode: { winnerTakesAllFiveVsFive: {} },
      creatorTeam: 0, // Team A
      creatorIndex:index,
      teamA:[teamA[1], teamA[0]], // Reversed
      teamB: []
    };

    try {
      await program.methods
        .createGameSession(createGameSessionArgs)
        .accountsPartial({
          user: user1.publicKey,
          gameSession: gameSessionKey,
          vault: vaultKey,
          userTokenAccount: user1TokenAccount,
          mint: mintKey
        })
        .signers([user1])
        .rpc(confirmOptions);
      assert.fail("This transaction should have failed with players not sorted");
    } catch (err) {
        assert(err instanceof anchor.AnchorError, "Unknown error");

        let anchorError = err;

        assert(anchorError.error.errorCode.code == "PlayersNotSorted");
    }
  });

  it("Fails to create game session with reserved players not distinct", async () => {
    const sessionId = getSessionId(12);

    const gameSessionKey = getGameSessionKey(program.programId, sessionId);

    const vaultKey = getVaultKey(program.programId, sessionId);

    // Sort the team and get the creator index    
    const [index, teamA] = getSortedAndCreatorIndex([user1.publicKey, user2.publicKey,]);
    
    // Arguments for the `create_game_session` instruction
    const createGameSessionArgs:types.CreateGameSessionArgs = {
      sessionId: sessionId,
      wagerAmount: sessionWager,
      gameMode: { winnerTakesAllFiveVsFive: {} },
      creatorTeam: 0, // Team A
      creatorIndex:index,
      teamA,
      teamB:[user1.publicKey]
    };

    try {
      await program.methods
        .createGameSession(createGameSessionArgs)
        .accountsPartial({
          user: user1.publicKey,
          gameSession: gameSessionKey,
          vault: vaultKey,
          userTokenAccount: user1TokenAccount,
          mint: mintKey
        })
        .signers([user1])
        .rpc(confirmOptions);
      assert.fail("This transaction should have failed with players not distinct");
    } catch (err) {
        assert(err instanceof anchor.AnchorError, "Unknown error");

        let anchorError = err;

        assert(anchorError.error.errorCode.code == "PlayersNotDistinct");
    }
  });

  it("Fails to create game session with invalid amount", async () => {
    const sessionId = getSessionId(13);

    const gameSessionKey = getGameSessionKey(program.programId, sessionId);

    const vaultKey = getVaultKey(program.programId, sessionId);

    // Attempt to create session with wrong mint
    const createGameSessionArgs:types.CreateGameSessionArgs = {
      sessionId: sessionId,
      wagerAmount: new BN(0), // A zero amount is not allowed
      gameMode: { winnerTakesAllOneVsOne: {} },
      creatorTeam: 0,
      creatorIndex:0,      
      teamA: [user1.publicKey],
      teamB: []
    };

    try {
      await program.methods
        .createGameSession(createGameSessionArgs)
        .accountsPartial({
          user: user1.publicKey,
          gameSession: gameSessionKey,
          vault: vaultKey,
          userTokenAccount: user1TokenAccount,
          mint: mintKey
        })
        .signers([user1])
        .rpc(confirmOptions);
      assert.fail("This transaction should have failed with invalid amount");
    } catch (err) {
       assert(err instanceof anchor.AnchorError, "Unknown error");

      let anchorError = err;

      assert(anchorError.error.errorCode.code == "InvalidWagerAmount");
    }
  });

  it("Fails to create game session with too many players", async () => {
    const sessionId = getSessionId(14);

    const gameSessionKey = getGameSessionKey(program.programId, sessionId);

    const vaultKey = getVaultKey(program.programId, sessionId);

    const [index, teamA] = getSortedAndCreatorIndex(
      [user1.publicKey, user2.publicKey, user3.publicKey, 
        user4.publicKey, user5.publicKey, user6.publicKey]);
    
    // Arguments for the `create_game_session` instruction
    // The are only one players in each team so there is no need for 
    // sorting   
    const createGameSessionArgs:types.CreateGameSessionArgs = {
      sessionId: sessionId,
      wagerAmount: sessionWager,
      gameMode: { winnerTakesAllFiveVsFive: {} },
      creatorTeam: 0, // Team A
      creatorIndex:index,
      teamA,
      teamB:[]
    };

    try {
      await program.methods
        .createGameSession(createGameSessionArgs)
        .accountsPartial({
          user: user1.publicKey,
          gameSession: gameSessionKey,
          vault: vaultKey,
          userTokenAccount: user1TokenAccount,
          mint: mintKey
        })
        .signers([user1])
        .rpc(confirmOptions);
      assert.fail("This transaction should have failed with invalid player count");
    } catch (err) {
        assert(err instanceof anchor.AnchorError, "Unknown error");

        let anchorError = err;

        assert(anchorError.error.errorCode.code == "InvalidPlayerCount");
    }
  });
});