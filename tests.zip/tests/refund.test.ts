import * as anchor from "@coral-xyz/anchor";
import { Program } from "@coral-xyz/anchor";
import { WagerProgram } from "../app/src/app/types/wager_program";
import { BN } from "@coral-xyz/anchor";
import * as types from "./types";
import {
  getSessionId,
  getGameSessionKey,
  getVaultKey,
  loadKeypair,
  setupTokenAccount,
  setupMintAndServer,
  getBalance,
  getVaultTokenAccount,
  getTokenBalance,
  airdropToAccounts,
  getGlobalConfigKey,
  getGameServerKeypair,
  getMintKey
} from "./utils";
import { PublicKey, Keypair } from "@solana/web3.js";
import { ConfirmOptions } from "@solana/web3.js";
import {AccountLayout, TOKEN_PROGRAM_ID} from "@solana/spl-token";
import { assert } from "chai";

const confirmOptions: ConfirmOptions = { commitment: "confirmed" };

describe("Refund", () => {
  // Setup environment
  const provider = anchor.AnchorProvider.env();
  anchor.setProvider(provider);
  const program = anchor.workspace.WagerProgram as Program<WagerProgram>;

  // Set mint and server
  const mintKey = getMintKey();

  let gameServerKeypair:Keypair;

  const user1 = Keypair.generate();
  const user2 = Keypair.generate();
  const user3 = Keypair.generate();
  const user4 = Keypair.generate();
  const user5 = Keypair.generate();
  const user6 = Keypair.generate();


  let globalConfigKey =  getGlobalConfigKey(program.programId);

  let user1TokenAccount: PublicKey;
  let user2TokenAccount: PublicKey;
  let user3TokenAccount: PublicKey;
  let user4TokenAccount: PublicKey;
  let user5TokenAccount: PublicKey;
  let user6TokenAccount: PublicKey;

  const wagerAmount = new BN(100_000_000); // 0.1 tokens

  const initialAmount = new BN(1_000_000_000) // 1 token


  before(async () => {

    gameServerKeypair = getGameServerKeypair();

    await airdropToAccounts(provider.connection, 
      [gameServerKeypair.publicKey, user1.publicKey, user2.publicKey, user3.publicKey, user4.publicKey, user5.publicKey, user6.publicKey]
    );
    
    user1TokenAccount = await setupTokenAccount(
      provider.connection,
      gameServerKeypair,
      mintKey,
      user1.publicKey,
      initialAmount.toNumber()
    );

    user2TokenAccount = await setupTokenAccount(
      provider.connection,
      gameServerKeypair,
      mintKey,
      user2.publicKey,
      initialAmount.toNumber()
    );

    user3TokenAccount = await setupTokenAccount(
      provider.connection,
      gameServerKeypair,
      mintKey,
      user3.publicKey,
      initialAmount.toNumber()
    );

    user4TokenAccount = await setupTokenAccount(
      provider.connection,
      gameServerKeypair,
      mintKey,
      user4.publicKey,
      initialAmount.toNumber()
    );

    user5TokenAccount = await setupTokenAccount(
      provider.connection,
      gameServerKeypair,
      mintKey,
      user5.publicKey,
      initialAmount.toNumber()
    );

    user6TokenAccount = await setupTokenAccount(
      provider.connection,
      gameServerKeypair,
      mintKey,
      user6.publicKey,
      initialAmount.toNumber()
    );

  });

  it("Successfully refunds wager", async () => {

    const sessionId = getSessionId(71);

    const gameSessionKey = getGameSessionKey(program.programId, sessionId);

    const vaultKey = getVaultKey(program.programId, sessionId);

    const vaultTokenAccountKey = getVaultTokenAccount(mintKey, vaultKey);


    console.log("Initial balances:-\n\n");
    console.log("User 1:-", await getTokenBalance(provider.connection, user1TokenAccount));
    console.log("User 2:-", await getTokenBalance(provider.connection, user2TokenAccount));
    console.log("User 3:-", await getTokenBalance(provider.connection, user3TokenAccount));


    const createGameSessionArgs:types.CreateGameSessionArgs = {
      sessionId: sessionId,
      wagerAmount: wagerAmount,
      gameMode: { winnerTakesAllThreeVsThree: {} },
      creatorTeam: 0, // Team A
      creatorIndex:0,
      teamA: [user1.publicKey],
      teamB: []
    };

    // Execute transaction
    await program.methods
      .createGameSession(createGameSessionArgs)
      .accountsPartial({
        user: user1.publicKey,
        gameSession: gameSessionKey,
        vault: vaultKey,
        userTokenAccount: user1TokenAccount,
        mint: mintKey,
      })
      .signers([user1])
      .rpc(confirmOptions);    

    console.log("After create - Vault balance:- ", 
      await getTokenBalance(provider.connection, vaultTokenAccountKey));

    // Execute transaction   
    await program.methods
      .joinUser({team:1})
      .accountsPartial({
        user: user2.publicKey,
        userTokenAccount: user2TokenAccount,
        gameSession:gameSessionKey,
        vault: vaultKey,
        mint: mintKey,
      })
      .signers([user2])
      .rpc(confirmOptions);

    // Execute transaction
   await program.methods
      .joinUser({team:0})
      .accountsPartial({
        user: user3.publicKey,
        userTokenAccount: user3TokenAccount,
        gameSession:gameSessionKey,
        vault: vaultKey,
        mint: mintKey,
      })
      .signers([user3])
      .rpc(confirmOptions);

    console.log("After joins - Vault balance:- ", 
      await getTokenBalance(provider.connection, vaultTokenAccountKey));

    let remainingAccounts = [
      {
        pubkey: user1.publicKey,
        isSigner: false,
        isWritable: true,
      },
      {
        pubkey: user1TokenAccount,
        isSigner: false,
        isWritable: true,
      },
      {
        pubkey: user3.publicKey,
        isSigner: false,
        isWritable: true,
      },
      {
        pubkey: user3TokenAccount,
        isSigner: false,
        isWritable: true,
      },
      {
        pubkey: user2.publicKey,
        isSigner: false,
        isWritable: true,
      },
      {
        pubkey: user2TokenAccount,
        isSigner: false,
        isWritable: true,
      },
    ]

    // Execute transaction
    await program.methods
      .refundWager()
      .accountsPartial({
        globalConfig:globalConfigKey,
        server: gameServerKeypair.publicKey,
        gameSession:gameSessionKey,
        creator:user1.publicKey
      })
      .remainingAccounts(remainingAccounts)
      .signers([gameServerKeypair])
      .rpc(confirmOptions);

    console.log("After refund:-\n\n");

    const user1FinalBalance = await getTokenBalance(provider.connection, user1TokenAccount);

    const user2FinalBalance = await getTokenBalance(provider.connection, user2TokenAccount);

    const user3FinalBalance = await getTokenBalance(provider.connection, user3TokenAccount);

    console.log("User 1:-", user1FinalBalance);

    console.log("User 2:-", user2FinalBalance);

    console.log("User 3:-", user3FinalBalance);

    // After refund, balances should be back to initial
    assert.equal(user1FinalBalance, initialAmount.toNumber());
    assert.equal(user2FinalBalance, initialAmount.toNumber());
    assert.equal(user3FinalBalance, initialAmount.toNumber());
  });

  it("Fails to refund wager, not enough accounts", async () => {

    const sessionId = getSessionId(72);

    const gameSessionKey = getGameSessionKey(program.programId, sessionId);

    const vaultKey = getVaultKey(program.programId, sessionId);

    const vaultTokenAccountKey = getVaultTokenAccount(mintKey, vaultKey);

    console.log("Initial balances:-\n\n");
    console.log("User 1:-", await getTokenBalance(provider.connection, user1TokenAccount));
    console.log("User 2:-", await getTokenBalance(provider.connection, user2TokenAccount));
    console.log("User 3:-", await getTokenBalance(provider.connection, user3TokenAccount));


    const createGameSessionArgs:types.CreateGameSessionArgs = {
      sessionId: sessionId,
      wagerAmount: wagerAmount,
      gameMode: { winnerTakesAllThreeVsThree: {} },
      creatorTeam: 0, // Team A
      creatorIndex:0,
      teamA: [user1.publicKey],
      teamB: []
    };

    // Execute transaction
    await program.methods
      .createGameSession(createGameSessionArgs)
      .accountsPartial({
        user: user1.publicKey,
        gameSession: gameSessionKey,
        vault: vaultKey,
        userTokenAccount: user1TokenAccount,
        mint: mintKey,
      })
      .signers([user1])
      .rpc(confirmOptions);    

    console.log("After create - Vault balance:- ", 
      await getTokenBalance(provider.connection, vaultTokenAccountKey));

    // Execute transaction   
    await program.methods
      .joinUser({team:1})
      .accountsPartial({
        user: user2.publicKey,
        userTokenAccount: user2TokenAccount,
        gameSession:gameSessionKey,
        vault: vaultKey,
        mint: mintKey,
      })
      .signers([user2])
      .rpc(confirmOptions);

    // Execute transaction
   await program.methods
      .joinUser({team:0})
      .accountsPartial({
        user: user3.publicKey,
        userTokenAccount: user3TokenAccount,
        gameSession:gameSessionKey,
        vault: vaultKey,
        mint: mintKey,
      })
      .signers([user3])
      .rpc(confirmOptions);

    console.log("After joins - Vault balance:- ", 
      await getTokenBalance(provider.connection, vaultTokenAccountKey));

    // Invalid remaning accounts, it is not complete.
    let remainingAccounts = [
      {
        pubkey: user1.publicKey,
        isSigner: false,
        isWritable: true,
      },
      {
        pubkey: user1TokenAccount,
        isSigner: false,
        isWritable: true,
      },
      {
        pubkey: user3.publicKey,
        isSigner: false,
        isWritable: true,
      },
      {
        pubkey: user3TokenAccount,
        isSigner: false,
        isWritable: true,
      }
    ]

  try{
    // Refund wager to players    
    await program.methods
      .refundWager()
      .accountsPartial({
        globalConfig:globalConfigKey,
        server: gameServerKeypair.publicKey,
        gameSession:gameSessionKey,
        creator:user1.publicKey
      })
      .remainingAccounts(remainingAccounts)
      .signers([gameServerKeypair])
      .rpc(confirmOptions);

    assert.fail("This transaction should have failed the remaining accounts are not complete.");
    } catch(err){
      assert(err instanceof anchor.AnchorError, "Unknown error");

      const anchorError = err;

      assert.equal(anchorError.error.errorCode.code, "InvalidRemainingAccounts");      
    }
  });

  it("Fails to refund wager, the accounts are not in order", async () => {

    const sessionId = getSessionId(73);

    const gameSessionKey = getGameSessionKey(program.programId, sessionId);

    const vaultKey = getVaultKey(program.programId, sessionId);

    const vaultTokenAccountKey = getVaultTokenAccount(mintKey, vaultKey);

    console.log("Initial balances:-\n\n");
    console.log("User 1:-", await getTokenBalance(provider.connection, user1TokenAccount));
    console.log("User 2:-", await getTokenBalance(provider.connection, user2TokenAccount));
    console.log("User 3:-", await getTokenBalance(provider.connection, user3TokenAccount));


    const createGameSessionArgs:types.CreateGameSessionArgs = {
      sessionId: sessionId,
      wagerAmount: wagerAmount,
      gameMode: { winnerTakesAllThreeVsThree: {} },
      creatorTeam: 0, // Team A
      creatorIndex:0,
      teamA: [user1.publicKey],
      teamB: []
    };

    // Execute transaction
    await program.methods
      .createGameSession(createGameSessionArgs)
      .accountsPartial({
        user: user1.publicKey,
        gameSession: gameSessionKey,
        vault: vaultKey,
        userTokenAccount: user1TokenAccount,
        mint: mintKey,
      })
      .signers([user1])
      .rpc(confirmOptions);    

    console.log("After create - Vault balance:- ", 
      await getTokenBalance(provider.connection, vaultTokenAccountKey));

    // Execute transaction   
    await program.methods
      .joinUser({team:1})
      .accountsPartial({
        user: user2.publicKey,
        userTokenAccount: user2TokenAccount,
        gameSession:gameSessionKey,
        vault: vaultKey,
        mint: mintKey,
      })
      .signers([user2])
      .rpc(confirmOptions);

    // Execute transaction
   await program.methods
      .joinUser({team:0})
      .accountsPartial({
        user: user3.publicKey,
        userTokenAccount: user3TokenAccount,
        gameSession:gameSessionKey,
        vault: vaultKey,
        mint: mintKey,
      })
      .signers([user3])
      .rpc(confirmOptions);

    console.log("After joins - Vault balance:- ", 
      await getTokenBalance(provider.connection, vaultTokenAccountKey));

    // Invalid remaning accounts, it is not in order.
    let remainingAccounts = [
      {
        pubkey: user1.publicKey,
        isSigner: false,
        isWritable: true,
      },
      {
        pubkey: user1TokenAccount,
        isSigner: false,
        isWritable: true,
      },
      {
        pubkey: user2.publicKey,
        isSigner: false,
        isWritable: true,
      },
      {
        pubkey: user2TokenAccount,
        isSigner: false,
        isWritable: true,
      },
      {
        pubkey: user3.publicKey,
        isSigner: false,
        isWritable: true,
      },
      {
        pubkey: user3TokenAccount,
        isSigner: false,
        isWritable: true,
      }
    ]

  try{
    // Execute transaction
    await program.methods
      .refundWager()
      .accountsPartial({
        globalConfig:globalConfigKey,
        server: gameServerKeypair.publicKey,
        gameSession:gameSessionKey,
        creator:user1.publicKey
      })
      .remainingAccounts(remainingAccounts)
      .signers([gameServerKeypair])
      .rpc(confirmOptions);

    assert.fail("This transaction should have failed the remaining accounts are not in order.");
    } catch(err){
      assert(err instanceof anchor.AnchorError, "Unknown error");

      const anchorError = err;

      assert.equal(anchorError.error.errorCode.code, "InvalidPlayer");      
    }
  });

    it("Fails to refund wager, the creator account is not valid", async () => {

    const sessionId = getSessionId(74);

    const gameSessionKey = getGameSessionKey(program.programId, sessionId);

    const vaultKey = getVaultKey(program.programId, sessionId);

    const vaultTokenAccountKey = getVaultTokenAccount(mintKey, vaultKey);

    console.log("Initial balances:-\n\n");
    console.log("User 1:-", await getTokenBalance(provider.connection, user1TokenAccount));
    console.log("User 2:-", await getTokenBalance(provider.connection, user2TokenAccount));
    console.log("User 3:-", await getTokenBalance(provider.connection, user3TokenAccount));


    const createGameSessionArgs:types.CreateGameSessionArgs = {
      sessionId: sessionId,
      wagerAmount: wagerAmount,
      gameMode: { winnerTakesAllThreeVsThree: {} },
      creatorTeam: 0, // Team A
      creatorIndex:0,
      teamA: [user1.publicKey],
      teamB: []
    };

    // Execute transaction
    await program.methods
      .createGameSession(createGameSessionArgs)
      .accountsPartial({
        user: user1.publicKey,
        gameSession: gameSessionKey,
        vault: vaultKey,
        userTokenAccount: user1TokenAccount,
        mint: mintKey,
      })
      .signers([user1])
      .rpc(confirmOptions);    

    console.log("After create - Vault balance:- ", 
      await getTokenBalance(provider.connection, vaultTokenAccountKey));

    // Execute transaction   
    await program.methods
      .joinUser({team:1})
      .accountsPartial({
        user: user2.publicKey,
        userTokenAccount: user2TokenAccount,
        gameSession:gameSessionKey,
        vault: vaultKey,
        mint: mintKey,
      })
      .signers([user2])
      .rpc(confirmOptions);

    // Execute transaction
   await program.methods
      .joinUser({team:0})
      .accountsPartial({
        user: user3.publicKey,
        userTokenAccount: user3TokenAccount,
        gameSession:gameSessionKey,
        vault: vaultKey,
        mint: mintKey,
      })
      .signers([user3])
      .rpc(confirmOptions);

    console.log("After joins - Vault balance:- ", 
      await getTokenBalance(provider.connection, vaultTokenAccountKey));

    // Invalid remaning accounts, it is not in order.
    let remainingAccounts = [
      {
        pubkey: user1.publicKey,
        isSigner: false,
        isWritable: true,
      },
      {
        pubkey: user1TokenAccount,
        isSigner: false,
        isWritable: true,
      },
      {
        pubkey: user3.publicKey,
        isSigner: false,
        isWritable: true,
      },
      {
        pubkey: user3TokenAccount,
        isSigner: false,
        isWritable: true,
      },
      {
        pubkey: user2.publicKey,
        isSigner: false,
        isWritable: true,
      },
      {
        pubkey: user2TokenAccount,
        isSigner: false,
        isWritable: true,
      }
    ]

  try{
    // Execute transaction
    await program.methods
      .refundWager()
      .accountsPartial({
        globalConfig:globalConfigKey,
        server: gameServerKeypair.publicKey,
        gameSession:gameSessionKey,
        creator:user2.publicKey
      })
      .remainingAccounts(remainingAccounts)
      .signers([gameServerKeypair])
      .rpc(confirmOptions);

    assert.fail("This transaction should have failed the creator account is invalid.");
    } catch(err){
      assert(err instanceof anchor.AnchorError, "Unknown error");

      const anchorError = err;

      assert.equal(anchorError.error.errorCode.code, "InvalidCreatorAccount");      
    }
  });

  it("Fails to refund wager, the server is not valid", async () => {

    const sessionId = getSessionId(75);

    const gameSessionKey = getGameSessionKey(program.programId, sessionId);

    const vaultKey = getVaultKey(program.programId, sessionId);

    const vaultTokenAccountKey = getVaultTokenAccount(mintKey, vaultKey);

    console.log("Initial balances:-\n\n");
    console.log("User 1:-", await getTokenBalance(provider.connection, user1TokenAccount));
    console.log("User 2:-", await getTokenBalance(provider.connection, user2TokenAccount));
    console.log("User 3:-", await getTokenBalance(provider.connection, user3TokenAccount));


    const createGameSessionArgs:types.CreateGameSessionArgs = {
      sessionId: sessionId,
      wagerAmount: wagerAmount,
      gameMode: { winnerTakesAllThreeVsThree: {} },
      creatorTeam: 0, // Team A
      creatorIndex:0,
      teamA: [user1.publicKey],
      teamB: []
    };

    // Execute transaction
    await program.methods
      .createGameSession(createGameSessionArgs)
      .accountsPartial({
        user: user1.publicKey,
        gameSession: gameSessionKey,
        vault: vaultKey,
        userTokenAccount: user1TokenAccount,
        mint: mintKey,
      })
      .signers([user1])
      .rpc(confirmOptions);    

    console.log("After create - Vault balance:- ", 
      await getTokenBalance(provider.connection, vaultTokenAccountKey));

    // Execute transaction   
    await program.methods
      .joinUser({team:1})
      .accountsPartial({
        user: user2.publicKey,
        userTokenAccount: user2TokenAccount,
        gameSession:gameSessionKey,
        vault: vaultKey,
        mint: mintKey,
      })
      .signers([user2])
      .rpc(confirmOptions);

    // Execute transaction
   await program.methods
      .joinUser({team:0})
      .accountsPartial({
        user: user3.publicKey,
        userTokenAccount: user3TokenAccount,
        gameSession:gameSessionKey,
        vault: vaultKey,
        mint: mintKey,
      })
      .signers([user3])
      .rpc(confirmOptions);

    console.log("After joins - Vault balance:- ", 
      await getTokenBalance(provider.connection, vaultTokenAccountKey));

    // Invalid remaning accounts, it is not in order.
    let remainingAccounts = [
      {
        pubkey: user1.publicKey,
        isSigner: false,
        isWritable: true,
      },
      {
        pubkey: user1TokenAccount,
        isSigner: false,
        isWritable: true,
      },
      {
        pubkey: user2.publicKey,
        isSigner: false,
        isWritable: true,
      },
      {
        pubkey: user2TokenAccount,
        isSigner: false,
        isWritable: true,
      },
      {
        pubkey: user3.publicKey,
        isSigner: false,
        isWritable: true,
      },
      {
        pubkey: user3TokenAccount,
        isSigner: false,
        isWritable: true,
      }
    ]

  const invalidGameServerKeypair = Keypair.generate();

  try{
    // Refund wager to players
    await program.methods
      .refundWager()
      .accountsPartial({
        globalConfig:globalConfigKey,
        server: invalidGameServerKeypair.publicKey,
        gameSession:gameSessionKey,
        creator:user1.publicKey,
      })
      .remainingAccounts(remainingAccounts)
      .signers([invalidGameServerKeypair])
      .rpc(confirmOptions);

    assert.fail("This transaction should have failed the server is not valid.");
  }catch(err){
      console.log("Error: ", err);
      
      assert(err instanceof anchor.AnchorError, "Unknown error");

      const anchorError = err;

      assert.equal(anchorError.error.errorCode.code, "InvalidAuthority");      
    }
  });


}); 